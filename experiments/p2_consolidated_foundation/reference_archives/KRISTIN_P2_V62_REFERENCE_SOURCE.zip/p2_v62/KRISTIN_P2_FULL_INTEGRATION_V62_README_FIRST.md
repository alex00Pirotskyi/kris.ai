# Kristin P2 Full Integration V62 — README FIRST

## Classification

**Guarded P2 consumer train; source package only.**

This package contains no P1 authority implementation, protected-key broker, signing handle bundle, P2-owned policy engine, grant issuer, durable-use ledger, revocation authority, or audit signer. It cannot be prepared unless protected main already contains a completed, independently reviewed, exact-CI-proven `P1A-001` authority-service amendment.

No `tasks/completed/P2-xxx.md` files are packaged and aggregate P2 remains `source_only_not_complete`.

## V62 authority model

The shipped ProductRuntime supplies `ProductRuntime.p1AuthorityService` from the separately merged P1A train. P2 is delegation-only:

```text
ProductRuntime / desktop control plane
  -> merged P1A OS-isolated typed authority service
  -> one-use effect permit and public verifier material
  -> supervised P2 automation worker
  -> real OS effect and structured receipt
```

The automation worker must be unable to connect to the authority service, access its OS key store, read protected handles, or request arbitrary signatures. Exact P1A service, provisioning, denial, and merged-manifest evidence is embedded in each completion-eligible platform receipt.

## Resumable integration stages

```bash
bash integrate_kristin_p2_full_train_v62.sh verify-package \
  --package KRISTIN_P2_FULL_INTEGRATION_V62.zip

bash integrate_kristin_p2_full_train_v62.sh prepare-source \
  --repo /c/dev/flutter/kris_studio_ai_2 \
  --package KRISTIN_P2_FULL_INTEGRATION_V62.zip

bash integrate_kristin_p2_full_train_v62.sh resume-source-ci ...
bash integrate_kristin_p2_full_train_v62.sh collect-review \
  ... --platform-receipt WINDOWS.json --platform-receipt MACOS.json --platform-receipt LINUX.json
bash integrate_kristin_p2_full_train_v62.sh resume-evidence \
  ... --security-review REVIEW.json --owner-approval OWNER.json
bash integrate_kristin_p2_full_train_v62.sh merge ...
```

The launcher persists exact source/evidence state outside the checkout, allows exact-SHA retry after local/CI/runner failure, and provides `status` plus explicit `discard-failed-branch --expected-sha` recovery. The ordinary operator checkout is checked byte-for-byte on exit.

## Evidence boundary

Every task requires machine-observed, task-specific Windows, macOS, and Linux assertions beginning at the shipped ProductRuntime and traversing the merged P1A service, production P2 adapter, real OS effect, postcondition, receipt, and signed post-run cleanup. String-only, helper-only, source-only, unsupported, skipped, blocked, absent, malformed, fixture-authority, or synthetic results cannot become `DONE`.

## Completion boundary

This package does not claim governed Flutter compilation, real Windows/macOS/Linux controlled-runner execution, P2-009 interactive desktop permissions, three real technology candidates, independent security approval, owner approval, PR test-merge checks, protected-main merge, or merged-main CI. Those remain mandatory.
