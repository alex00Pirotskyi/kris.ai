# P2-001 owner approval

Status: **PENDING**

Approval must be a separate JSON artifact bound to the exact reviewed commit, tree, V62 package digest, and the exact platform-receipt hashes. A command-line name is not approval.
