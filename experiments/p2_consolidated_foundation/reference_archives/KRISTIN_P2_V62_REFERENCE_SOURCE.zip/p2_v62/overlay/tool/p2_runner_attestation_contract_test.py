#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json,os,pathlib,platform,shutil,subprocess,sys,tempfile
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent));from ed25519_ref import public_key
ROOT=pathlib.Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def dump(p,v):pathlib.Path(p).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n',encoding='utf-8')
def make(parent,name,content='x'):
 p=parent/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content,encoding='utf-8');return p
def invoke(env,policy,job,out,expect=True):
 c=subprocess.run([sys.executable,str(ROOT/'tool/p2_runner_attestation.py'),'--project',str(ROOT),'--policy',str(policy),'--job-identity',str(job),'--output',str(out),'--platform','linux','--commit-sha','a'*40],env=env,text=True,capture_output=True)
 if (c.returncode==0)!=expect:raise AssertionError((c.returncode,c.stdout,c.stderr))
def main():
 if platform.system()!='Linux':print('P2 runner attestation V5 contract: SKIP non-Linux');return 0
 with tempfile.TemporaryDirectory(prefix='p2-runner-att-v5-') as td:
  t=pathlib.Path(td);roots={n:t/n for n in ('runtime','p1a','package','service','e2e')}
  for p in roots.values():p.mkdir()
  config=make(t,'configuration.json','{"status":"passed"}\n');cleanup=make(t,'cleanup-provider','#!/bin/sh\nexit 1\n');cleanup.chmod(0o755)
  manifest={'schemaVersion':'1.0.0','phase':'P1A','status':'passed','completionClaim':True,'independentSecurityReview':'approved','reviewedCommit':'b'*40,'reviewedTree':'c'*40,'platformEvidence':{'linux':'passed','macos':'passed','windows':'passed'}}
  att={'schemaVersion':'1.0.0','attestationType':'p1-authority-service-attestation-v1','platform':'linux','status':'passed','serviceInstanceId':'p1a-linux-1','serviceBuildSha256':'1'*64,'sourceTree':'2'*64,'authorityProtocolSha256':'3'*64,'serviceIdentitySha256':'4'*64,'osEnforcedIsolation':True,'workerPrincipalSeparated':True,'typedOperationsOnly':True,'nonExportableKeys':True,'workerDeniedByOs':True,'arbitraryMessageSigningApi':False,'completionEligible':True}
  provision={'schemaVersion':'1.0.0','receiptType':'p1-authority-service-provisioning-v1','platform':'linux','status':'passed','serviceInstalled':True,'separateOsIdentity':True,'keyNonExportable':True,'desktopPrincipalAuthenticated':True,'workerPrincipalDenied':True,'completionEligible':True}
  denial={'schemaVersion':'1.0.0','receiptType':'p1-authority-worker-denial-v1','platform':'linux','status':'passed','workerKeyReadDenied':True,'workerServiceConnectDenied':True,'workerOsKeyStoreDenied':True,'arbitrarySigningDenied':True,'replayAfterRestartDenied':True,'zeroAuthorityArtifactsReadable':True,'completionEligible':True}
  p1a_files={'p1AuthorityServiceMergedManifest':make(roots['p1a'],'manifest.json',json.dumps(manifest)),'p1AuthorityServiceAttestation':make(roots['p1a'],'att.json',json.dumps(att)),'p1AuthorityServiceProvisioningReceipt':make(roots['p1a'],'provision.json',json.dumps(provision)),'p1AuthorityServiceWorkerDenialReceipt':make(roots['p1a'],'denial.json',json.dumps(denial))}
  other={'controlledPackageArchive':make(roots['package'],'package.tgz'),'controlledServiceDefinition':make(roots['service'],'service.json'),'technologyNodeReceipt':make(t,'node.json'),'technologyNativeReceipt':make(t,'native.json'),'technologyDartReceipt':make(t,'dart.json')}
  files={**p1a_files,**other};dirs={'e2eWorkspaceRoot':roots['e2e'],'applicationRuntimeRoot':roots['runtime'],'p1AuthorityServiceEvidenceRoot':roots['p1a'],'controlledPackageRoot':roots['package'],'controlledServiceRoot':roots['service']}
  resources={**{k:{'kind':'file','path':str(v.resolve()),'sha256':sha(v)} for k,v in files.items()},**{k:{'kind':'directory','path':str(v.resolve())} for k,v in dirs.items()}}
  module=pathlib.Path(sys.modules['ed25519_ref'].__file__).resolve();shutil.copy2(module,t/'ed25519_ref.py');seed=bytes(range(32));pub=public_key(seed).hex()
  extra={'labels':['self-hosted','kristin-p2','linux','interactive-desktop','ubuntu-24.04'],'hostPlatform':'linux','hostImageSha256':'1'*64,'configurationReceiptPath':str(config.resolve()),'configurationSha256':sha(config),'interactiveSession':{'loggedIn':True,'identity':'fixture-user','sessionId':'fixture-desktop'},'permissions':{'clipboard':True,'screenCapture':True,'activeWindow':True,'accessibility':True},'noConcurrentUntrustedWorkload':True,'workerCannotAccessAuthorityService':True,'p2ReceivesAuthoritySecrets':False,'controlledOperations':{'packageManager':'npm-local-controlled','packageName':'fixture-package','serviceProvider':'systemd-user','serviceId':'fixture.service'},'controlledResources':resources};extra_path=t/'extra.json';dump(extra_path,extra)
  provider=t/'attest-provider.py';provider.write_text(f'''#!/usr/bin/env python3
import argparse,datetime as dt,json,pathlib,sys
sys.path.insert(0,{str(t)!r});from ed25519_ref import public_key,sign
SEED=bytes(range(32))
def canonical(v):return (json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False)+"\\n").encode()
a=argparse.ArgumentParser();a.add_argument("--request");a.add_argument("--output");n=a.parse_args();r=json.loads(pathlib.Path(n.request).read_text());extra=json.loads(pathlib.Path({str(extra_path)!r}).read_text());now=dt.datetime.now(dt.timezone.utc);body={{**r,**extra,"schemaVersion":"5.0.0","attestationType":"p2-controlled-runner-attestation-v5","validFrom":(now-dt.timedelta(seconds=1)).isoformat(),"validUntil":(now+dt.timedelta(minutes=5)).isoformat(),"publicKeyHex":public_key(SEED).hex()}};body["signatureHex"]=sign(SEED,canonical(body)).hex();pathlib.Path(n.output).write_text(json.dumps(body,indent=2,sort_keys=True)+"\\n")
''');provider.chmod(0o755)
  labels=extra['labels'];row={'runnerId':42,'runnerName':'fixture-runner','runnerGroup':'kristin-p2-controlled','runnerGroupId':9,'labels':labels,'hostImageSha256':'1'*64,'configurationReceiptPath':str(config.resolve()),'configurationSha256':sha(config),'attestationProviderPath':str(provider.resolve()),'attestationProviderSha256':sha(provider),'postRunCleanupProviderPath':str(cleanup.resolve()),'postRunCleanupProviderSha256':sha(cleanup)}
  policy={'schemaVersion':'5.0.0','policyType':'p2-controlled-runner-policy-v5','requiredPermissions':['clipboard','screenCapture','activeWindow','accessibility'],'maximumAttestationAgeSeconds':900,'attestationTrustRoots':[pub],'cleanupTrustRoots':[pub],'provisioningPacketSha256':'5'*64,'runners':{'linux':row}};pol=t/'policy.json';dump(pol,policy)
  job={'schemaVersion':'1.0.0','receiptType':'p2-github-job-identity-v1','repository':'owner/repo','repositoryId':77,'workflowName':'P2 Owner Mode','workflowPath':'.github/workflows/p2-owner-mode.yml','workflowRef':'owner/repo/.github/workflows/p2-owner-mode.yml@refs/heads/test','workflowRunId':'123','runAttempt':1,'jobName':'p2-behavioral-linux','githubJobId':456,'sourceCommit':'a'*40,'runnerId':42,'runnerName':'fixture-runner','runnerGroupId':9,'runnerGroup':'kristin-p2-controlled','labels':labels,'platform':'linux','apiPayloadSha256':'6'*64,'runnerEphemeralSessionId':'ephemeral-123','status':'observed'};jobp=t/'job.json';dump(jobp,job);job_sha=sha(jobp)
  env={**os.environ,'GITHUB_REPOSITORY':'owner/repo','GITHUB_REPOSITORY_ID':'77','GITHUB_WORKFLOW':'P2 Owner Mode','GITHUB_WORKFLOW_REF':job['workflowRef'],'GITHUB_RUN_ID':'123','GITHUB_RUN_ATTEMPT':'1','GITHUB_JOB':'p2-behavioral-linux','GITHUB_SHA':'a'*40,'KRISTIN_P2_GITHUB_JOB_ID':'456','KRISTIN_P2_RUNNER_ID':'42','RUNNER_NAME':'fixture-runner','KRISTIN_P2_RUNNER_GROUP':'kristin-p2-controlled','KRISTIN_P2_RUNNER_GROUP_ID':'9','KRISTIN_P2_GITHUB_JOB_IDENTITY_SHA256':job_sha,'KRISTIN_P2_RUNNER_EPHEMERAL_SESSION_ID':'ephemeral-123'}
  out=t/'receipt.json';invoke(env,pol,jobp,out,True);receipt=json.loads(out.read_text());assert receipt['p1AuthorityService']['workerDenialReceiptSha256']==sha(p1a_files['p1AuthorityServiceWorkerDenialReceipt']) and receipt['completionEligibleForTaskClosure'] is False
  for key,value in [('GITHUB_RUN_ID','999'),('GITHUB_RUN_ATTEMPT','2'),('GITHUB_JOB','another-job'),('KRISTIN_P2_GITHUB_JOB_ID','999'),('KRISTIN_P2_RUNNER_EPHEMERAL_SESSION_ID','replayed-session')]:invoke({**env,key:value},pol,jobp,t/f'bad-{key}.json',False)
  bad=json.loads(files['p1AuthorityServiceWorkerDenialReceipt'].read_text());bad['workerServiceConnectDenied']=False;dump(files['p1AuthorityServiceWorkerDenialReceipt'],bad);resources['p1AuthorityServiceWorkerDenialReceipt']['sha256']=sha(files['p1AuthorityServiceWorkerDenialReceipt']);dump(extra_path,extra);invoke(env,pol,jobp,t/'bad-denial.json',False)
 print('P2 exact runner/P1A isolation attestation V5 contract: PASS');return 0
if __name__=='__main__':raise SystemExit(main())
