import crypto from 'node:crypto';

export function canonical(value) {
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`;
  if (value && typeof value === 'object') {
    return `{${Object.keys(value)
      .sort()
      .map((key) => `${JSON.stringify(key)}:${canonical(value[key])}`)
      .join(',')}}`;
  }
  return JSON.stringify(value);
}

export function canonicalBytes(value) {
  return Buffer.from(canonical(value), 'utf8');
}

export function exactJsonEqual(left, right) {
  return canonical(left) === canonical(right);
}

export function sha256Json(value) {
  return crypto.createHash('sha256').update(canonicalBytes(value)).digest('hex');
}

export function sha256Bytes(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

export function exactObjectKeys(value, expected, errorCode) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error(errorCode);
  }
  if (!exactJsonEqual(Object.keys(value).sort(), [...expected].sort())) {
    throw new Error(errorCode);
  }
}

export function rawEd25519PublicKeyToSpki(rawHex) {
  if (!/^[0-9a-f]{64}$/i.test(rawHex ?? '')) {
    throw new Error('ed25519_public_key_invalid');
  }
  // RFC 8410 SubjectPublicKeyInfo prefix for an Ed25519 raw 32-byte key.
  return Buffer.concat([
    Buffer.from('302a300506032b6570032100', 'hex'),
    Buffer.from(rawHex, 'hex'),
  ]);
}

export function ed25519PublicKeyFromRawHex(rawHex) {
  return crypto.createPublicKey({
    key: rawEd25519PublicKeyToSpki(rawHex),
    format: 'der',
    type: 'spki',
  });
}

export function rawEd25519PublicKeyHex(publicKey) {
  const der = publicKey.export({ format: 'der', type: 'spki' });
  const prefix = Buffer.from('302a300506032b6570032100', 'hex');
  if (der.length !== prefix.length + 32 || !der.subarray(0, prefix.length).equals(prefix)) {
    throw new Error('ed25519_public_key_encoding_invalid');
  }
  return der.subarray(prefix.length).toString('hex');
}
