import crypto from 'node:crypto';
import { canonical } from './authenticated-ipc.mjs';

const PKCS8_PREFIX = Buffer.from('302e020100300506032b657004220420', 'hex');
const SPKI_PREFIX = Buffer.from('302a300506032b6570032100', 'hex');
export const TEST_PERMIT_SEED_HEX = '44'.repeat(32);
export const TEST_PERMIT_KEY_ID = 'p1-effect-permit-test';

function privateKey() {
  return crypto.createPrivateKey({
    key: Buffer.concat([PKCS8_PREFIX, Buffer.from(TEST_PERMIT_SEED_HEX, 'hex')]),
    format: 'der',
    type: 'pkcs8',
  });
}

export function testPublicKeyHex() {
  const der = crypto.createPublicKey(privateKey()).export({ format: 'der', type: 'spki' });
  if (!Buffer.from(der).subarray(0, SPKI_PREFIX.length).equals(SPKI_PREFIX)) throw new Error('test_spki_invalid');
  return Buffer.from(der).subarray(-32).toString('hex');
}

export function digest(value) {
  return crypto.createHash('sha256').update(canonical(value)).digest('hex');
}

function fakeMac(label) {
  return crypto.createHash('sha256').update(label).digest('hex');
}

export function createTestAuthority({
  roots = ['/tmp'],
  taskId = 'task',
  toolId = 'pty',
  runId = 'run',
  actorId = 'actor',
  capabilityId = 'cap',
  maxUses = 100,
  channelId = `channel-${crypto.randomUUID()}`,
  workerSessionId = `worker-${crypto.randomUUID()}`,
  initialUses = {},
  initialRequests = [],
  initialStateVersion = 0,
  revocationEpoch = 7,
} = {}) {
  const seedKey = privateKey();
  const publicKeyHex = testPublicKeyHex();
  const grants = new Map();
  const grantUses = new Map(Object.entries(initialUses));
  const requestIds = new Set(initialRequests);
  let stateVersion = initialStateVersion;
  const sharedAuthorityInstanceId = `p1-shared-${crypto.randomUUID()}`;

  function bootstrap() {
    return {
      schemaVersion: '3.0.0',
      permitVerifier: {
        algorithm: 'ed25519',
        keyId: TEST_PERMIT_KEY_ID,
        publicKeyHex,
      },
      channelId,
      workerSessionId,
      authorityState: {
        revocationEpoch,
        revokedGrantIds: [],
        authoritativeGrantUses: Object.fromEntries(grantUses),
        authoritativeConsumedRequestIds: [...requestIds],
        authoritativeStateVersion: stateVersion,
        sharedAuthorityInstanceId,
      },
    };
  }

  function next(operation = 'pty.open', payload = {}, { expectedGrantDigest = null } = {}) {
    const now = Date.now();
    const requestId = crypto.randomUUID();
    const notBefore = new Date(now - 1000).toISOString();
    const expiresAt = new Date(now + 60_000).toISOString();
    let grant;
    if (expectedGrantDigest) {
      grant = grants.get(expectedGrantDigest);
      if (!grant) throw new Error('test_expected_grant_unknown');
    } else {
      grant = {
        schemaVersion: '2.0.0',
        grantId: `grant-${crypto.randomUUID()}`,
        issuer: { actorId: 'desktop_host', authority: 'desktop_host:deterministic_policy' },
        binding: { runId, taskId, actorId, toolId, accessProfileId: 'owner' },
        scope: {
          paths: { roots: [...roots] },
          process: { interactive: true },
          network: { listen: false },
          browser: {},
          secrets: { rawReveal: false, leaseIds: [] },
        },
        budgets: { wallClockMs: 60_000, maxOutputBytes: 8 * 1024 * 1024, maxNetworkBytes: 0, maxCostMicros: 0, maxMutations: 100 },
        validity: { issuedAt: new Date(now).toISOString(), notBefore, expiresAt, maxUses },
        nonce: crypto.randomUUID(),
        auth: { algorithm: 'hmac-sha256', keyId: 'desktop-only-grant-test', mac: fakeMac(`grant:${requestId}`) },
      };
      grants.set(digest(grant), grant);
    }
    const grantDigest = digest(grant);
    const previousUse = grantUses.get(grant.grantId) ?? 0;
    const useNumber = previousUse + 1;
    stateVersion += 1;
    const policyDecision = {
      schemaVersion: '2.0.0',
      status: 'allow',
      decisionId: `decision-${crypto.randomUUID()}`,
      binding: { runId, taskId, actorId, toolId, accessProfileId: 'owner', capabilityId },
      effect: { action: operation, p2Operation: operation },
    };
    const consumptionReceipt = {
      schemaVersion: '1.0.0',
      grantId: grant.grantId,
      requestId,
      useNumber,
      previousUseNumber: previousUse,
      stateVersion,
      revocationEpoch,
      consumedAt: new Date().toISOString(),
      auth: { algorithm: 'hmac-sha256', keyId: 'desktop-only-consumption-test', mac: fakeMac(`consume:${requestId}:${stateVersion}`) },
    };
    const authenticatedIpc = {
      schemaVersion: '2.0.0',
      transportType: 'p1-authenticated-local-ipc-v2',
      authenticationMode: 'desktop-ed25519-one-use-effect-permit',
      peerId: 'desktop-host',
      channelId,
      requestId,
      workerCanIssue: false,
      symmetricKeyMaterialTransferred: false,
    };
    const auditCheckpoint = {
      id: `audit-${stateVersion}`,
      digest: fakeMac(`audit:${stateVersion}`),
      sequence: stateVersion,
    };
    const authority = {
      sharedP1ControlPlane: true,
      workerCanIssue: false,
      instanceId: sharedAuthorityInstanceId,
      implementationSha256: fakeMac('P1SharedDesktopControlPlane'),
      runtimeBuildSha256: fakeMac('runtime-build'),
    };
    const authorization = {
      runId, taskId, actorId, toolId, accessProfileId: 'owner', capabilityId, operation,
      grantId: grant.grantId,
      grantDigest,
      policyDecisionId: policyDecision.decisionId,
      policyDecisionDigest: digest(policyDecision),
      scopeDigest: digest(grant.scope),
      notBefore: grant.validity.notBefore,
      expiresAt: grant.validity.expiresAt,
      useNumber,
      maxUses: grant.validity.maxUses,
      revocationEpoch,
      capabilityGrant: grant,
      policyDecision,
      consumptionReceipt,
      authenticatedIpc,
      auditCheckpoint,
      authority,
    };
    const exactPayload = { operation, ...payload };
    const permitUnsigned = {
      schemaVersion: '1.0.0',
      permitType: 'p1-desktop-one-use-effect-permit-v1',
      permitId: `permit-${crypto.randomUUID()}`,
      workerSessionId,
      channelId,
      peerId: 'desktop-host',
      requestId,
      operation,
      binding: { runId, taskId, actorId, toolId, accessProfileId: 'owner', capabilityId },
      authorizationSha256: digest(authorization),
      payloadSha256: digest(exactPayload),
      grantId: grant.grantId,
      grantDigest,
      policyDecisionId: policyDecision.decisionId,
      policyDecisionDigest: authorization.policyDecisionDigest,
      scopeDigest: authorization.scopeDigest,
      consumptionReceiptSha256: digest(consumptionReceipt),
      useNumber,
      maxUses: grant.validity.maxUses,
      revocationEpoch,
      authoritativeStateVersion: stateVersion,
      auditCheckpointId: auditCheckpoint.id,
      auditCheckpointSha256: auditCheckpoint.digest,
      sharedAuthorityInstanceId,
      authorityImplementationSha256: fakeMac('P1SharedDesktopControlPlane'),
      runtimeBuildSha256: fakeMac('runtime-build'),
      sourceCommit: 'a'.repeat(40),
      sourceTree: 'b'.repeat(40),
      issuedAt: new Date(now).toISOString(),
      notBefore,
      expiresAt,
      algorithm: 'ed25519',
      signerKeyId: TEST_PERMIT_KEY_ID,
    };
    const signatureHex = crypto.sign(null, Buffer.from(canonical(permitUnsigned)), seedKey).toString('hex');
    const envelope = {
      schemaVersion: '3.0.0',
      requestId,
      deadline: expiresAt,
      authorization,
      effectPermit: { ...permitUnsigned, signatureHex },
      payload: exactPayload,
    };
    grantUses.set(grant.grantId, useNumber);
    requestIds.add(requestId);
    return envelope;
  }

  return Object.freeze({ bootstrap, next, publicKeyHex, channelId, workerSessionId, privateKey: seedKey });
}
