import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'p2_automation_host.dart';

class P2AutomationHostException implements Exception {
  const P2AutomationHostException(this.code, [this.message = '']);

  final String code;
  final String message;

  @override
  String toString() => message.isEmpty
      ? 'P2AutomationHostException($code)'
      : 'P2AutomationHostException($code, $message)';
}

abstract interface class P2ProtectedAutomationBootstrapProvider {
  /// Returns one protected bootstrap payload containing only key handles resolved
  /// by the desktop authority and its durable grant/replay state.
  Future<Map<String, Object?>> take();
}

final class P2OneShotAutomationBootstrap
    implements P2ProtectedAutomationBootstrapProvider {
  P2OneShotAutomationBootstrap(Map<String, Object?> value)
      : _value = Map<String, Object?>.from(value);

  Map<String, Object?>? _value;

  @override
  Future<Map<String, Object?>> take() async {
    final value = _value;
    _value = null;
    if (value == null) {
      throw const P2AutomationHostException('bootstrap_already_consumed');
    }
    return value;
  }

  @override
  String toString() => 'P2OneShotAutomationBootstrap([PROTECTED])';
}

final class P2AutomationHostLaunchConfig {
  const P2AutomationHostLaunchConfig({
    required this.nodeExecutable,
    required this.hostScript,
    required this.workingDirectory,
    required this.bootstrapProvider,
    this.windowsJobHelper,
    this.posixWatchdog,
    this.interactiveDesktopAdapter,
    this.interactiveDesktopAttested = false,
    this.fixtureRoot,
    this.additionalEnvironment = const <String, String>{},
    this.startupTimeout = const Duration(seconds: 15),
    this.maxTransportLineBytes = 16 * 1024 * 1024,
  });

  final String nodeExecutable;
  final String hostScript;
  final String workingDirectory;
  final P2ProtectedAutomationBootstrapProvider bootstrapProvider;
  final String? windowsJobHelper;
  final String? posixWatchdog;
  final String? interactiveDesktopAdapter;
  final bool interactiveDesktopAttested;
  final String? fixtureRoot;
  final Map<String, String> additionalEnvironment;
  final Duration startupTimeout;
  final int maxTransportLineBytes;

  static bool _isAbsolute(String value) {
    if (Platform.isWindows) {
      return RegExp(r'^[A-Za-z]:[\\/]').hasMatch(value) ||
          value.startsWith(r'\\');
    }
    return value.startsWith('/');
  }

  void validate() {
    if (!_isAbsolute(nodeExecutable) || !File(nodeExecutable).existsSync()) {
      throw const P2AutomationHostException('node_executable_required');
    }
    if (!_isAbsolute(hostScript) || !File(hostScript).existsSync()) {
      throw const P2AutomationHostException('automation_host_script_required');
    }
    if (!_isAbsolute(workingDirectory) ||
        !Directory(workingDirectory).existsSync()) {
      throw const P2AutomationHostException('automation_host_cwd_required');
    }
    for (final optional in <String?>[
      windowsJobHelper,
      posixWatchdog,
      interactiveDesktopAdapter,
    ]) {
      if (optional != null &&
          (!_isAbsolute(optional) || !File(optional).existsSync())) {
        throw const P2AutomationHostException('native_helper_invalid');
      }
    }
    if (fixtureRoot != null && !_isAbsolute(fixtureRoot!)) {
      throw const P2AutomationHostException('fixture_root_invalid');
    }
    if (startupTimeout <= Duration.zero ||
        startupTimeout > const Duration(minutes: 2)) {
      throw const P2AutomationHostException('startup_timeout_invalid');
    }
    if (maxTransportLineBytes < 65536 ||
        maxTransportLineBytes > 64 * 1024 * 1024) {
      throw const P2AutomationHostException('transport_line_budget_invalid');
    }
    for (final entry in additionalEnvironment.entries) {
      if (entry.key.contains('=') ||
          entry.key.contains('\u0000') ||
          entry.value.contains('\u0000')) {
        throw const P2AutomationHostException('environment_invalid');
      }
      if (RegExp(
        r'(secret|token|password|credential|api.?key|private.?key)',
        caseSensitive: false,
      ).hasMatch(entry.key)) {
        throw const P2AutomationHostException(
          'secret_environment_key_forbidden',
        );
      }
    }
  }
}

/// Concrete production transport for the supervised automation host.
///
/// Protected bootstrap material crosses only the private parent/child pipe after
/// a child-generated challenge. It never appears in argv, environment, ordinary
/// logs, transcripts, screenshots, or release evidence.
final class P2ProcessAutomationHostClient implements P2AutomationHostClient {
  P2ProcessAutomationHostClient._(this._process, this._config) {
    _stdoutSubscription = _process.stdout
        .transform(utf8.decoder)
        .transform(const LineSplitter())
        .listen(_handleLine, onError: _handleTransportError, onDone: _handleDone);
    _stderrSubscription = _process.stderr.listen((List<int> bytes) {
      _stderrBytes += bytes.length;
      if (_stderrBytes > 4 * 1024 * 1024) {
        _failAll(
          const P2AutomationHostException('automation_host_stderr_flood'),
        );
        _process.kill();
      }
    });
    unawaited(_watchExit());
  }

  static Future<P2ProcessAutomationHostClient> start(
    P2AutomationHostLaunchConfig config,
  ) async {
    config.validate();
    final environment = <String, String>{
      for (final key in const <String>[
        'PATH',
        'Path',
        'SystemRoot',
        'WINDIR',
        'HOME',
        'USERPROFILE',
        'TMP',
        'TEMP',
        'LANG',
        'LC_ALL',
        'DISPLAY',
        'WAYLAND_DISPLAY',
        'XDG_RUNTIME_DIR',
        'DBUS_SESSION_BUS_ADDRESS',
      ])
        if (Platform.environment[key] case final value?) key: value,
      if (config.windowsJobHelper != null)
        'KRISTIN_WINDOWS_JOB_HELPER': config.windowsJobHelper!,
      if (config.posixWatchdog != null)
        'KRISTIN_POSIX_WATCHDOG_HELPER': config.posixWatchdog!,
      if (config.interactiveDesktopAdapter != null)
        'KRISTIN_INTERACTIVE_DESKTOP_ADAPTER':
            config.interactiveDesktopAdapter!,
      if (config.interactiveDesktopAttested)
        'KRISTIN_P2_INTERACTIVE_DESKTOP': '1',
      if (config.fixtureRoot != null)
        'KRISTIN_P2_FIXTURE_ROOT': config.fixtureRoot!,
      ...config.additionalEnvironment,
    };
    final process = await Process.start(
      config.nodeExecutable,
      <String>[config.hostScript],
      workingDirectory: config.workingDirectory,
      environment: environment,
      includeParentEnvironment: false,
      runInShell: false,
      mode: ProcessStartMode.normal,
    );
    final client = P2ProcessAutomationHostClient._(process, config);
    try {
      final challenge = await client._challenge.future.timeout(
        config.startupTimeout,
      );
      final bootstrap = await config.bootstrapProvider.take();
      client._sendJson(<String, Object?>{
        'type': 'bootstrap',
        'schemaVersion': '3.0.0',
        'challenge': challenge,
        ...bootstrap,
      });
      await client._ready.future.timeout(config.startupTimeout);
      return client;
    } on TimeoutException {
      await client.close();
      throw const P2AutomationHostException('automation_host_start_timeout');
    } catch (_) {
      await client.close();
      rethrow;
    }
  }

  final Process _process;
  final P2AutomationHostLaunchConfig _config;
  final Completer<String> _challenge = Completer<String>();
  final Completer<void> _ready = Completer<void>();
  final Map<String, Completer<Map<String, Object?>>> _pending =
      <String, Completer<Map<String, Object?>>>{};
  final StreamController<Map<String, Object?>> _events =
      StreamController<Map<String, Object?>>.broadcast(sync: true);
  late final StreamSubscription<String> _stdoutSubscription;
  late final StreamSubscription<List<int>> _stderrSubscription;
  int _stderrBytes = 0;
  bool _closing = false;
  bool _closed = false;

  Stream<Map<String, Object?>> get events => _events.stream;
  int get pid => _process.pid;
  bool get isClosed => _closed;

  @override
  Future<Map<String, Object?>> invoke(P2AutomationEnvelope envelope) async {
    envelope.validate();
    if (_closed || _closing) {
      throw const P2AutomationHostException('automation_host_closed');
    }
    await _ready.future;
    if (_pending.containsKey(envelope.requestId)) {
      throw const P2AutomationHostException('duplicate_request_id');
    }
    final remaining = envelope.deadline.toUtc().difference(
          DateTime.now().toUtc(),
        );
    if (remaining <= Duration.zero) {
      throw const P2AutomationHostException('deadline_expired');
    }
    final completer = Completer<Map<String, Object?>>();
    _pending[envelope.requestId] = completer;
    _sendJson(envelope.toJson());
    try {
      return await completer.future.timeout(remaining);
    } on TimeoutException {
      _pending.remove(envelope.requestId);
      throw const P2AutomationHostException('automation_host_deadline_unknown');
    }
  }

  @override
  Stream<Map<String, Object?>> stream(
    String requestId, {
    required P2EffectBinding binding,
    required P2WorkerGrantProof grantProof,
  }) {
    return _events.stream.where((Map<String, Object?> event) {
      final openRequestId = event['requestId'] ?? event['openRequestId'];
      if (openRequestId != requestId) return false;
      final rawBinding = event['authorizationBinding'];
      if (rawBinding is! Map) return false;
      final value = Map<String, Object?>.from(rawBinding);
      return value['runId'] == binding.runId &&
          value['taskId'] == binding.taskId &&
          value['actorId'] == binding.actorId &&
          value['grantId'] == grantProof.grantId &&
          value['grantDigest'] == grantProof.grantDigest;
    });
  }

  @override
  Future<Map<String, Object?>> cancel(P2AutomationEnvelope envelope) {
    if (envelope.operation != 'control.cancel') {
      throw const P2AutomationHostException(
        'authorized_cancel_envelope_required',
      );
    }
    return invoke(envelope);
  }

  @override
  Future<void> close() async {
    if (_closed || _closing) return;
    _closing = true;
    try {
      _sendJson(const <String, Object?>{'type': 'shutdown'});
    } catch (_) {
      // Continue to bounded termination.
    }
    try {
      await _process.exitCode.timeout(const Duration(seconds: 5));
    } on TimeoutException {
      _process.kill(ProcessSignal.sigkill);
      await _process.exitCode.timeout(
        const Duration(seconds: 3),
        onTimeout: () => -1,
      );
    } finally {
      _closed = true;
      _closing = false;
      await _stdoutSubscription.cancel();
      await _stderrSubscription.cancel();
      _failAll(const P2AutomationHostException('automation_host_closed'));
      await _events.close();
    }
  }

  void _sendJson(Map<String, Object?> value) {
    if (_closed) throw const P2AutomationHostException('automation_host_closed');
    final line = jsonEncode(value);
    if (utf8.encode(line).length > _config.maxTransportLineBytes) {
      throw const P2AutomationHostException('transport_line_budget_exceeded');
    }
    _process.stdin.writeln(line);
  }

  void _handleLine(String line) {
    if (utf8.encode(line).length > _config.maxTransportLineBytes) {
      _handleTransportError(
        const P2AutomationHostException('transport_line_budget_exceeded'),
      );
      _process.kill();
      return;
    }
    final Object? decoded;
    try {
      decoded = jsonDecode(line);
    } catch (_) {
      _handleTransportError(
        const P2AutomationHostException('automation_host_protocol_invalid'),
      );
      return;
    }
    if (decoded is! Map) return;
    final message = Map<String, Object?>.from(decoded);
    final type = message['type'];
    if (type == 'bootstrap.challenge') {
      final challenge = message['challenge']?.toString() ?? '';
      if (!RegExp(r'^[0-9a-f]{64}$').hasMatch(challenge)) {
        _handleTransportError(
          const P2AutomationHostException('bootstrap_challenge_invalid'),
        );
      } else if (!_challenge.isCompleted) {
        _challenge.complete(challenge);
      }
      return;
    }
    if (type == 'ready') {
      if (message['executorOnly'] != true ||
          message['grantIssuer'] != false ||
          message['authenticatedIpcRequired'] != true ||
          message['desktopIssuedEffectPermitRequired'] != true ||
          message['publicVerifierOnly'] != true ||
          message['rawAuthorityKeysPresent'] != false ||
          message['desktopIssuedEffectPermitRequired'] != true ||
          message['publicVerifierOnly'] != true ||
          message['rawAuthorityKeysPresent'] != false) {
        if (!_ready.isCompleted) {
          _ready.completeError(
            const P2AutomationHostException('ready_contract_invalid'),
          );
        }
      } else if (!_ready.isCompleted) {
        _ready.complete();
      }
      return;
    }
    if (type == 'response') {
      final requestId = message['requestId']?.toString();
      final completer = requestId == null ? null : _pending.remove(requestId);
      if (completer != null) {
        final response = Map<String, Object?>.from(message)
          ..remove('type')
          ..remove('requestId');
        completer.complete(response);
      }
      return;
    }
    if (type == 'fatal') {
      _handleTransportError(
        P2AutomationHostException(
          message['code']?.toString() ?? 'automation_host_fatal',
          _safeDiagnostic(message['message']?.toString() ?? ''),
        ),
      );
      return;
    }
    if (!_events.isClosed) _events.add(message);
  }

  String _safeDiagnostic(String value) {
    if (RegExp(
      r'(secret|token|password|authorization|api.?key|private.?key|bearer)',
      caseSensitive: false,
    ).hasMatch(value)) {
      return '[REDACTED: credential-shaped diagnostic]';
    }
    return value.length <= 2048
        ? value
        : value.substring(value.length - 2048);
  }

  void _handleTransportError(Object error, [StackTrace? stack]) {
    final failure = error is P2AutomationHostException
        ? error
        : const P2AutomationHostException('automation_host_transport_failed');
    if (!_challenge.isCompleted) _challenge.completeError(failure, stack);
    if (!_ready.isCompleted) _ready.completeError(failure, stack);
    _failAll(failure, stack);
  }

  void _handleDone() {
    if (!_closed && !_closing) {
      _handleTransportError(
        const P2AutomationHostException('automation_host_transport_closed'),
      );
    }
  }

  Future<void> _watchExit() async {
    final code = await _process.exitCode;
    if (!_closed && !_closing && code != 0) {
      _handleTransportError(
        P2AutomationHostException('automation_host_exited', '$code'),
      );
    }
  }

  void _failAll(Object error, [StackTrace? stack]) {
    for (final completer in _pending.values) {
      if (!completer.isCompleted) completer.completeError(error, stack);
    }
    _pending.clear();
  }
}
