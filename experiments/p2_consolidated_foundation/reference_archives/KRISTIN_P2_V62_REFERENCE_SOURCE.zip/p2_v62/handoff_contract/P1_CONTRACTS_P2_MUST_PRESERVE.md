# P1 contracts that P2 must preserve

P2 is the first phase that exercises broad machine authority. It must consume the P1 trust stack directly.

## Access profiles

- `chat`: no host mutation authority
- `project`: bounded project authority
- `owner`: explicit interactive full-current-account ceiling; not sandboxed
- `owner_unattended`: unattended current-account ceiling with stricter secret/elevation boundaries
- `isolated_untrusted`: sandboxed hostile-workload profile with no host credentials

P2 cannot blur these modes or treat Owner Mode as a project-root escape hatch.

## Capability Grant v2

Every effect binds to run, task, actor, tool/operation, access profile, applicable scope, budgets, expiry, and use count. Workers reject modified, expired, replayed, exhausted, or wrong-run grants.

## Deterministic policy engine

- deny by default
- deterministic overlay order
- narrowing is monotonic
- widening requires trusted explicit approval and cannot exceed the profile ceiling
- model or untrusted content cannot approve or widen authority

## Trust, audit, and IPC

- Signed Manifest v2 uses external trust roots; legacy v1 never authorizes trust.
- Private material is not stored in repository or plain settings; revoked keys fail closed.
- High-authority effects produce append-only evidence and signed checkpoints.
- Worker invocation requires authenticated local transport, peer identity, request identity, deadlines, limits, and versioning.

## Ownership boundaries

- desktop host: policy, storage, grant, and evidence authority
- automation host: supervised lifecycle/execution boundary only
- workers: execute only within grants
- model/content/environment: never authority
