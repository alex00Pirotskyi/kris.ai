# P2 test and evidence matrix

## Shared test layers

1. Schema/source contracts
2. Unit tests
3. Behavioral fixtures
4. Adversarial fixtures
5. Windows/macOS/Linux smoke evidence
6. UX/accessibility tests
7. Release/assurance gates

## Minimum task evidence

| Task | Required behavioral evidence |
|---|---|
| P2-001 | Enable/disable/reset, persistent mode indicator, approval-policy and data-boundary UI tests |
| P2-002 | absolute/drive/share paths, hidden/Unicode/long paths, symlink/reparse races, transactional mutation |
| P2-003 | direct executable/cwd/env, bounded output, cancel/timeout, outside-project Owner-only enforcement |
| P2-004 | measured technology comparison and accepted ADR |
| P2-005 | input/resize/ANSI/Unicode/attach/detach/reconnect/transcript on all three OSes |
| P2-006 | descendants, PID reuse, parent death, timeout, graceful stop and forced kill |
| P2-007 | fixture package operations, dry run, SDK provenance, target-image smoke receipts |
| P2-008 | service/app support matrix, honest unsupported behavior, rollback/restart notes |
| P2-009 | clipboard/screen capability checks, redaction, no ordinary-log content leak |
| P2-010 | file backup/Git checkpoint/restore behavior and explicit non-restorable classification |
| P2-011 | frozen UI, runaway output and descendant process emergency kill |
| P2-012 | tabs, shell/cwd, search, save/copy, interrupt/terminate/attach, keyboard/screen reader |
| P2-013 | destructive/race/flood/process-bomb/crash/restart adversarial corpus |
| P2-014 | guide-to-UI and guide-to-behavior consistency checks |

For every task create `IMPLEMENTATION.md`, `OWNER_APPROVAL.md`, `manifest.json`, and `test-results.json`, plus aggregate P2 evidence and an independent security-review packet.

Source markers are not behavioral proof. Missing real execution evidence must remain `source_only`, `unsupported`, or `not_tested`.
