# P2 security-review requirements

P2 introduces full-current-account effects and is security-critical.

Review authorization at the final effect boundary; grant integrity/revocation/expiry/use consumption; path canonicalization and symlink/reparse TOCTOU; command/shell injection; environment handling; secrets in argv/env/transcript/logs/screenshots; PTY escape/output flooding; process-tree identity, descendant escape, parent death and PID reuse; elevation; clipboard/screen privacy; rollback honesty; emergency kill independence; restart reconciliation; and Owner Mode versus isolated-untrusted labeling.

The implementation-producing AI conversation must not label itself an independent security reviewer. It must prepare a separate review packet with architecture diff, high-authority entry points, platform support matrix, adversarial results, residual risks, reversibility taxonomy, kill-path design, secret-flow analysis, and reviewer sign-off fields.
