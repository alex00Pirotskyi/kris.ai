# P2 parallel branch and rebase strategy

## Current known state

- Protected main: `53e1a3bf7e62960d397a245974243f4f5df5d858`
- Exact main CI: `30296551653`
- Complete P1 closure branch: `integration/p1-full-closure-v54`
- Reviewed P1 closure commit: `6f401868b4663ea7fc268dbf5fe92bbd160b5e2a`
- V54 branch CI failed only because `tasks/active` was empty and absent in clean macOS/Linux clones.
- V55 adds `tasks/active/.gitkeep`, refreshes the source manifest, reruns tri-OS CI, and merges P1.
- The final P1 protected-main SHA is intentionally not hardcoded.

## Side-branch rule

Create `integration/p2-full-train-wip` from the newest available authoritative P1 closure ref. Prefer `origin/integration/p1-full-closure-v54` while it exists and contains P1 closure evidence; otherwise use `origin/main` only after full P1 closure. Record the exact base SHA and never merge P2 before rebasing onto final P1 protected main.

## Conflict-minimizing commit structure

1. `feat(p2-a): owner settings filesystem and finite execution`
2. `feat(p2-b): automation host pty and process lifecycle`
3. `feat(p2-c): package service clipboard screen and undo`
4. `feat(p2-d): watchdog terminal ux adversarial suite and guide`
5. `chore(p2-integration): roadmap ci evidence inventories and source manifest`

Keep shared integration surfaces out of commits 1-4 when practical.

## Known conflict surfaces

- `.github/workflows/ci.yml`
- `SOURCE_MANIFEST.sha256`
- `docs/roadmap/STATUS.md`, `HANDOFF.md`, `DECISIONS.md`, `roadmap.yaml`
- `tool/validate_release.py`, `tool/verify.sh`
- `test/product/source_contract_test.dart`
- `tasks/active/.gitkeep`

Resolve these after rebasing and regenerate authoritative output rather than blindly choosing one side.
